import React from 'react';

function ChatHeader() {
    return (
        <header className="chat-header">
            Elior & Yagel
        </header>
    );
}

export default ChatHeader;
